# -*- coding: utf-8 -*-
from . import magento
from . import magento_attributes
from . import magento_store
from . import product